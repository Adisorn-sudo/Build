#pragma once

enum COM_PLAYERCAMP {
 ComPlayercampMid = 0,
 ComPlayercamp1 = 1,
 ComPlayercamp2 = 2,
};

uintptr_t energy;
bool HackMap;
int zoom2;

//อันนี้ hackmap 
//====================
void (*_SetVisible)(...);
void SetVisible(void *instance, int camp, bool bVisible, const bool forceSync = false) {
    if (instance != NULL && HackMap) {
    if (camp == 1 || camp == 2) {
      bVisible = true;
    }
  }
   return _SetVisible(instance, camp, bVisible, forceSync);
}
//====================

void (*set_depth)(void *instance, float amount);
void (*old_CameraSystemUpdate)(void *instance);
void CameraSystemUpdate(void *instance) {
    if (instance != NULL && zoom2 > 0) {
                   if (zoom2 == 1 ) {
                set_depth(instance,float(1.3f));
            } else if (zoom2 == 2) {
                set_depth(instance,float(1.5f));
            } else if (zoom2 == 3)  {
                set_depth(instance,float(1.7f));
            } else if (zoom2 == 4)  {
                set_depth(instance,float(1.9f));
            } else if (zoom2 == 5)  {
                set_depth(instance,float(2.1f));
            } else if (zoom2 == 6)  {
                set_depth(instance,float(2.3f));
            } else if (zoom2 == 7)  {
                set_depth(instance,float(2.5f));
            } else if (zoom2 == 8)  {
                set_depth(instance,float(2.7f));
            } else if (zoom2 == 9)  {
                set_depth(instance,float(2.9f));
            } else if (zoom2 == 10) {
                set_depth(instance,float(3.1f));
            } 
    }
    return old_CameraSystemUpdate(instance);
}