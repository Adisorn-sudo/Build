#pragma once

#include "Includes.h"
#include "Il2Cpp.h"
#include "Vector2.h"
#include "Vector3.h"
#include "Rect.h"
#include "Quaternion.h"