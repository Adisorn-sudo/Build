#pragma once

#include "ImGui/imgui.h"
#include "variables.h"

// ฟังก์ชันหลักสำหรับวาด Menu
void DrawMenu() {
    if (!g_Initialized) return;
    
    // ถ้ายังไม่ได้เปิด menu ก็ไม่ต้องวาด
    static bool showMenu = true; // เปลี่ยนเป็น false ถ้าต้องการให้ซ่อนตอนเริ่มต้น
    
    // Toggle menu ด้วยปุ่ม (ตัวอย่าง)
    ImGuiIO& io = ImGui::GetIO();
    
    if (!showMenu) return;
    
    // กำหนดขนาดและตำแหน่ง window
    ImGui::SetNextWindowSize(ImVec2(400, 600), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowPos(ImVec2(50, 50), ImGuiCond_FirstUseEver);
    
    // สร้าง main window
    ImGui::Begin("Minecraft Mod Menu", &showMenu, ImGuiWindowFlags_NoCollapse);
    
    // Tabs
    if (ImGui::BeginTabBar("ModTabs")) {
        
        // ===== Combat Tab =====
        if (ImGui::BeginTabItem("Combat")) {
            ImGui::Text("Combat Features");
            ImGui::Separator();
            
            // ตัวอย่าง toggles - ต้องมี variables ที่ประกาศใน variables.h
            extern bool AntiKnockBack;
            ImGui::Checkbox("Anti KnockBack", &AntiKnockBack);
            
            extern bool FastDrop;
            ImGui::Checkbox("Fast Drop", &FastDrop);
            
            extern float BlockReach;
            ImGui::SliderFloat("Block Reach", &BlockReach, 0.0f, 10.0f);
            
            ImGui::EndTabItem();
        }
        
        // ===== Movement Tab =====
        if (ImGui::BeginTabItem("Movement")) {
            ImGui::Text("Movement Features");
            ImGui::Separator();
            
            extern bool SpeedHack;
            extern float SpeedValue;
            ImGui::Checkbox("Speed Hack", &SpeedHack);
            ImGui::SliderFloat("Speed", &SpeedValue, 1.0f, 5.0f);
            
            extern bool JumpHack;
            extern float JumpValue;
            ImGui::Checkbox("Jump Hack", &JumpHack);
            ImGui::SliderFloat("Jump Height", &JumpValue, 1.0f, 5.0f);
            
            extern bool Noclip;
            ImGui::Checkbox("Noclip", &Noclip);
            if (Noclip) {
                hexPatches.Noclip.Modify();
            } else {
                hexPatches.Noclip.Restore();
            }
            
            extern bool Fly;
            extern float FlySpeed;
            ImGui::Checkbox("Fly", &Fly);
            ImGui::SliderFloat("Fly Speed", &FlySpeed, 1.0f, 10.0f);
            
            ImGui::EndTabItem();
        }
        
        // ===== Visual Tab =====
        if (ImGui::BeginTabItem("Visual")) {
            ImGui::Text("Visual Features");
            ImGui::Separator();
            
            extern bool FullBright;
            ImGui::Checkbox("Full Bright", &FullBright);
            if (FullBright) {
                hexPatches.FullBright.Modify();
            } else {
                hexPatches.FullBright.Restore();
            }
            
            extern bool NoFog;
            ImGui::Checkbox("No Fog", &NoFog);
            
            extern float Fov;
            ImGui::SliderFloat("FOV", &Fov, 30.0f, 120.0f);
            
            extern bool NoHurtCam;
            ImGui::Checkbox("No Hurt Camera", &NoHurtCam);
            if (NoHurtCam) {
                hexPatches.NoHurtCam.Modify();
            } else {
                hexPatches.NoHurtCam.Restore();
            }
            
            extern bool Xray;
            ImGui::Checkbox("X-Ray", &Xray);
            
            ImGui::EndTabItem();
        }
        
        // ===== Player Tab =====
        if (ImGui::BeginTabItem("Player")) {
            ImGui::Text("Player Features");
            ImGui::Separator();
            
            extern bool WaterDrown;
            ImGui::Checkbox("No Water Drown", &WaterDrown);
            if (WaterDrown) {
                hexPatches.WaterDrown.Modify();
            } else {
                hexPatches.WaterDrown.Restore();
            }
            
            extern bool LavaDrown;
            ImGui::Checkbox("No Lava Drown", &LavaDrown);
            if (LavaDrown) {
                hexPatches.LavaDrown.Modify();
            } else {
                hexPatches.LavaDrown.Restore();
            }
            
            extern bool NoSlowDown;
            ImGui::Checkbox("No Slow Down", &NoSlowDown);
            if (NoSlowDown) {
                hexPatches.NoSlowDown.Modify();
            } else {
                hexPatches.NoSlowDown.Restore();
            }
            
            extern float Gravity;
            ImGui::SliderFloat("Gravity", &Gravity, -2.0f, 2.0f);
            
            ImGui::EndTabItem();
        }
        
        // ===== Misc Tab =====
        if (ImGui::BeginTabItem("Misc")) {
            ImGui::Text("Miscellaneous");
            ImGui::Separator();
            
            extern bool AutoClickMine;
            ImGui::Checkbox("Auto Click Mine", &AutoClickMine);
            if (AutoClickMine) {
                hexPatches.AutoClickMine.Modify();
            } else {
                hexPatches.AutoClickMine.Restore();
            }
            
            extern bool FastBridge;
            ImGui::Checkbox("Fast Bridge", &FastBridge);
            
            extern bool NoBlur;
            ImGui::Checkbox("No Blur", &NoBlur);
            if (NoBlur) {
                hexPatches.NoBlur1.Modify();
                hexPatches.NoBlur2.Modify();
            } else {
                hexPatches.NoBlur1.Restore();
                hexPatches.NoBlur2.Restore();
            }
            
            // Font Size selector
            extern int FontSize;
            const char* fontSizes[] = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" };
            static int selectedFont = 5; // Default
            if (ImGui::Combo("Font Size", &selectedFont, fontSizes, IM_ARRAYSIZE(fontSizes))) {
                // Apply font patch based on selection
                hexPatches.Font0.Restore();
                hexPatches.Font1.Restore();
                hexPatches.Font2.Restore();
                hexPatches.Font3.Restore();
                hexPatches.Font4.Restore();
                hexPatches.Font5.Restore();
                hexPatches.Font6.Restore();
                hexPatches.Font7.Restore();
                hexPatches.Font8.Restore();
                hexPatches.Font9.Restore();
                hexPatches.Font10.Restore();
                
                switch(selectedFont) {
                    case 0: hexPatches.Font0.Modify(); break;
                    case 1: hexPatches.Font1.Modify(); break;
                    case 2: hexPatches.Font2.Modify(); break;
                    case 3: hexPatches.Font3.Modify(); break;
                    case 4: hexPatches.Font4.Modify(); break;
                    case 5: hexPatches.Font5.Modify(); break;
                    case 6: hexPatches.Font6.Modify(); break;
                    case 7: hexPatches.Font7.Modify(); break;
                    case 8: hexPatches.Font8.Modify(); break;
                    case 9: hexPatches.Font9.Modify(); break;
                    case 10: hexPatches.Font10.Modify(); break;
                }
            }
            
            ImGui::EndTabItem();
        }
        
        // ===== Settings Tab =====
        if (ImGui::BeginTabItem("Settings")) {
            ImGui::Text("Settings");
            ImGui::Separator();
            
            if (ImGui::Button("Save Config", ImVec2(150, 30))) {
                // Save config to JSON
                SaveConfig();
            }
            
            ImGui::SameLine();
            
            if (ImGui::Button("Load Config", ImVec2(150, 30))) {
                // Load config from JSON
                LoadConfig();
            }
            
            if (ImGui::Button("Reset All", ImVec2(150, 30))) {
                // Reset all patches
                hexPatches.Noclip.Restore();
                hexPatches.FullBright.Restore();
                hexPatches.NoHurtCam.Restore();
                hexPatches.WaterDrown.Restore();
                hexPatches.LavaDrown.Restore();
                hexPatches.NoSlowDown.Restore();
                hexPatches.AutoClickMine.Restore();
                hexPatches.NoBlur1.Restore();
                hexPatches.NoBlur2.Restore();
                // ... restore all other patches
            }
            
            ImGui::Separator();
            
            ImGui::Text("Info:");
            ImGui::BulletText("Version: 1.0.0");
            ImGui::BulletText("Build: No JNI");
            ImGui::BulletText("Author: YourName");
            
            ImGui::EndTabItem();
        }
        
        ImGui::EndTabBar();
    }
    
    ImGui::End();
}

// ฟังก์ชัน Save/Load Config (ตัวอย่าง)
void SaveConfig() {
    json j;
    
    extern bool AntiKnockBack, SpeedHack, JumpHack, Noclip, Fly;
    extern bool FullBright, NoFog, NoHurtCam, Xray;
    extern bool WaterDrown, LavaDrown, NoSlowDown;
    extern bool AutoClickMine, FastBridge, NoBlur;
    extern float SpeedValue, JumpValue, FlySpeed, Fov, Gravity, BlockReach;
    
    j["combat"] = {
        {"antiKnockBack", AntiKnockBack},
        {"blockReach", BlockReach}
    };
    
    j["movement"] = {
        {"speedHack", SpeedHack},
        {"speedValue", SpeedValue},
        {"jumpHack", JumpHack},
        {"jumpValue", JumpValue},
        {"noclip", Noclip},
        {"fly", Fly},
        {"flySpeed", FlySpeed}
    };
    
    j["visual"] = {
        {"fullBright", FullBright},
        {"noFog", NoFog},
        {"fov", Fov},
        {"noHurtCam", NoHurtCam},
        {"xray", Xray}
    };
    
    j["player"] = {
        {"waterDrown", WaterDrown},
        {"lavaDrown", LavaDrown},
        {"noSlowDown", NoSlowDown},
        {"gravity", Gravity}
    };
    
    j["misc"] = {
        {"autoClickMine", AutoClickMine},
        {"fastBridge", FastBridge},
        {"noBlur", NoBlur}
    };
    
    std::ofstream file(oxorany("/data/data/") + GameName + oxorany("/xal/config.json"));
    file << j.dump(4);
    file.close();
    
    LOGI("Config saved!");
}

void LoadConfig() {
    std::ifstream file(oxorany("/data/data/") + GameName + oxorany("/xal/config.json"));
    if (!file.good()) {
        LOGE("Config file not found!");
        return;
    }
    
    json j;
    file >> j;
    
    extern bool AntiKnockBack, SpeedHack, JumpHack, Noclip, Fly;
    extern bool FullBright, NoFog, NoHurtCam, Xray;
    extern bool WaterDrown, LavaDrown, NoSlowDown;
    extern bool AutoClickMine, FastBridge, NoBlur;
    extern float SpeedValue, JumpValue, FlySpeed, Fov, Gravity, BlockReach;
    
    if (j.contains("combat")) {
        AntiKnockBack = j["combat"]["antiKnockBack"];
        BlockReach = j["combat"]["blockReach"];
    }
    
    if (j.contains("movement")) {
        SpeedHack = j["movement"]["speedHack"];
        SpeedValue = j["movement"]["speedValue"];
        JumpHack = j["movement"]["jumpHack"];
        JumpValue = j["movement"]["jumpValue"];
        Noclip = j["movement"]["noclip"];
        Fly = j["movement"]["fly"];
        FlySpeed = j["movement"]["flySpeed"];
    }
    
    // ... load other settings
    
    file.close();
    
    LOGI("Config loaded!");
}
