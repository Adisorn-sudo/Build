void BeginDraw() {
     ImGuiIO &io = ImGui::GetIO();
     ImVec2 center = ImGui::GetMainViewport()->GetCenter();
     
     ImGui::SetNextWindowSize(ImVec2(500, 500), ImGuiCond_Once);
     if (ImGui::Begin(OBFUSCATE("Jorny Shop is the best"))) {
		g_window = ImGui::GetCurrentWindow();
        //ImGui::Text("%.1f FPS", io.Framerate);
		if (ImGui::BeginTabBar(OBFUSCATE("Tab"))) {
			if (ImGui::BeginTabItem(OBFUSCATE("Main"))) {
                #if defined(__aarch64__)
                ImGui::Text(OBFUSCATE("Bit: 64")); 
                #else
                ImGui::Text(OBFUSCATE("Bit: 32")); 
                #endif
                ImGui::Separator();
                ImGui::Text(OBFUSCATE("Made By Mai bog"));
				ImGui::Separator();
				ImGui::Text(OBFUSCATE("Telegram @mSORRYBRO")); 
                ImGui::EndTabItem();
            }
            if (ImGui::BeginTabItem(OBFUSCATE("Hack"))) {
                ImGui::Checkbox("Hack map", &HackMap);
                ImGui::TableNextColumn();
                ImGui::Text("CAMERA");
                ImGui::SliderInt("##DroneView", &zoom2, 0.0f, 10.0f);
            }
			ImGui::EndTabBar();
        }
    }
}
