/*
 * Pure Native Android Application - NO JNI
 * Using android_native_app_glue instead of JNI
 */

#include <android_native_app_glue.h>
#include <android/native_window.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>

#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <sstream>
#include <vector>
#include <pthread.h>
#include <codecvt>
#include <chrono>
#include <queue>
#include <sys/system_properties.h>

// ImGui includes
#include "ImGui/imgui_internal.h"
#include "ImGui/imgui.h"
#include "ImGui/backends/imgui_impl_android.h"
#include "ImGui/backends/imgui_impl_opengl3.h"

// Custom includes
#include "ImGui/FONTS/DEFAULT.h"
#include <Includes/Utils.h>
#include <Includes/Dobby/dobby.h>
#include <Includes/obfuscate.h>
#include "KittyMemory/MemoryPatch.h"
#include "TuanMeta/Call_Me.h"
#include "Hook.h"

// IDA Pro defines
typedef uint32_t _DWORD;
typedef uint64_t _QWORD;
#define __int8 char
#define __int16 short
#define __int32 int
#define __int64 long long

// Global variables
struct Engine {
    struct android_app* app;
    EGLDisplay display;
    EGLSurface surface;
    EGLContext context;
    int32_t width;
    int32_t height;
    bool initialized;
    bool animating;
};

static Engine g_engine;
static bool g_ImGuiInitialized = false;
static ImGuiWindow* g_window = NULL;

struct My_Patches {
    MemoryPatch ;
} hexPatches;

// EGL initialization
static int engine_init_display(Engine* engine) {
    const EGLint attribs[] = {
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_BLUE_SIZE, 8,
        EGL_GREEN_SIZE, 8,
        EGL_RED_SIZE, 8,
        EGL_ALPHA_SIZE, 8,
        EGL_DEPTH_SIZE, 24,
        EGL_STENCIL_SIZE, 8,
        EGL_NONE
    };
    
    const EGLint context_attribs[] = {
        EGL_CONTEXT_CLIENT_VERSION, 3,
        EGL_NONE
    };

    EGLDisplay display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (display == EGL_NO_DISPLAY) {
        LOGE("eglGetDisplay failed");
        return -1;
    }

    EGLint major, minor;
    if (!eglInitialize(display, &major, &minor)) {
        LOGE("eglInitialize failed");
        return -1;
    }

    EGLConfig config;
    EGLint numConfigs;
    if (!eglChooseConfig(display, attribs, &config, 1, &numConfigs)) {
        LOGE("eglChooseConfig failed");
        return -1;
    }

    EGLSurface surface = eglCreateWindowSurface(display, config, engine->app->window, NULL);
    if (surface == EGL_NO_SURFACE) {
        LOGE("eglCreateWindowSurface failed");
        return -1;
    }

    EGLContext context = eglCreateContext(display, config, EGL_NO_CONTEXT, context_attribs);
    if (context == EGL_NO_CONTEXT) {
        LOGE("eglCreateContext failed");
        return -1;
    }

    if (!eglMakeCurrent(display, surface, surface, context)) {
        LOGE("eglMakeCurrent failed");
        return -1;
    }

    eglQuerySurface(display, surface, EGL_WIDTH, &engine->width);
    eglQuerySurface(display, surface, EGL_HEIGHT, &engine->height);

    engine->display = display;
    engine->context = context;
    engine->surface = surface;
    engine->initialized = true;

    // Initialize ImGui
    if (!g_ImGuiInitialized) {
        IMGUI_CHECKVERSION();
        ImGui::CreateContext();
        ImGuiIO& io = ImGui::GetIO();
        
        // Set ImGui Style
        ImGui::StyleColorsClassic();
     
        // Setup Platform/Renderer backends
        ImGui_ImplAndroid_Init(engine->app->window);
        ImGui_ImplOpenGL3_Init("#version 300 es");
        ImGui::GetStyle().ScaleAllSizes(3.5f);

        // Setup fonts
        static const ImWchar icons_ranges[] = { 0xf000, 0xf3ff, 0x0900, 0x097F, 0 };
        ImFontConfig font_config;
        ImFontConfig icons_config;
        ImFontConfig CustomFont;
        CustomFont.FontDataOwnedByAtlas = false;
        icons_config.MergeMode = true;
        icons_config.PixelSnapH = true;
        icons_config.OversampleH = 2.5;
        icons_config.OversampleV = 2.5;
        io.Fonts->AddFontFromMemoryTTF(const_cast<std::uint8_t*>(Custom3), sizeof(Custom3), 30.f, &CustomFont, io.Fonts->GetGlyphRangesCyrillic());
        
        g_ImGuiInitialized = true;
    }

    return 0;
}

// Draw one frame
static void engine_draw_frame(Engine* engine) {
    if (!engine->initialized || !g_ImGuiInitialized) {
        return;
    }

    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2((float)engine->width, (float)engine->height);

    // Start the Dear ImGui frame
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame();
    ImGui::NewFrame();

    // Draw menu
    BeginDraw();

    // Rendering
    ImGui::EndFrame();
    ImGui::Render();
    
    glViewport(0, 0, engine->width, engine->height);
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    
    eglSwapBuffers(engine->display, engine->surface);
}

// Terminate display
static void engine_term_display(Engine* engine) {
    if (g_ImGuiInitialized) {
        ImGui_ImplOpenGL3_Shutdown();
        ImGui_ImplAndroid_Shutdown();
        ImGui::DestroyContext();
        g_ImGuiInitialized = false;
    }

    if (engine->display != EGL_NO_DISPLAY) {
        eglMakeCurrent(engine->display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (engine->context != EGL_NO_CONTEXT) {
            eglDestroyContext(engine->display, engine->context);
        }
        if (engine->surface != EGL_NO_SURFACE) {
            eglDestroySurface(engine->display, engine->surface);
        }
        eglTerminate(engine->display);
    }
    
    engine->animating = false;
    engine->display = EGL_NO_DISPLAY;
    engine->context = EGL_NO_CONTEXT;
    engine->surface = EGL_NO_SURFACE;
    engine->initialized = false;
}

// Menu drawing function
void BeginDraw() {
    ImGuiIO &io = ImGui::GetIO();
    ImVec2 center = ImGui::GetMainViewport()->GetCenter();
    
    ImGui::SetNextWindowSize(ImVec2(500, 500), ImGuiCond_Once);
    if (ImGui::Begin(OBFUSCATE("Jorny Shop is the best"))) {
        g_window = ImGui::GetCurrentWindow();
        
        if (ImGui::BeginTabBar(OBFUSCATE("Tab"))) {
            if (ImGui::BeginTabItem(OBFUSCATE("Main"))) {
                #if defined(__aarch64__)
                ImGui::Text(OBFUSCATE("Bit: 64")); 
                #else
                ImGui::Text(OBFUSCATE("Bit: 32")); 
                #endif
                ImGui::Separator();
                ImGui::Text(OBFUSCATE("Made By Mai bog"));
                ImGui::Separator();
                ImGui::Text(OBFUSCATE("Telegram @mSORRYBRO")); 
                ImGui::EndTabItem();
            }
            
            if (ImGui::BeginTabItem(OBFUSCATE("Hack"))) {
                ImGui::Checkbox("Hack map", &HackMap);
                ImGui::TableNextColumn();
                ImGui::Text("CAMERA");
                ImGui::SliderInt("##DroneView", &zoom2, 0, 10);
                ImGui::EndTabItem();
            }
            
            ImGui::EndTabBar();
        }
        ImGui::End();
    }
}

// Process input events
static int32_t engine_handle_input(struct android_app* app, AInputEvent* event) {
    if (!g_ImGuiInitialized) {
        return 0;
    }

    ImGuiIO& io = ImGui::GetIO();
    
    int32_t eventType = AInputEvent_getType(event);
    
    switch (eventType) {
        case AINPUT_EVENT_TYPE_MOTION: {
            int32_t action = AMotionEvent_getAction(event);
            int32_t actionMasked = action & AMOTION_EVENT_ACTION_MASK;
            
            float x = AMotionEvent_getX(event, 0);
            float y = AMotionEvent_getY(event, 0);
            
            switch (actionMasked) {
                case AMOTION_EVENT_ACTION_DOWN:
                case AMOTION_EVENT_ACTION_POINTER_DOWN:
                    io.MouseDown[0] = true;
                    io.MousePos = ImVec2(x, y);
                    return 1;
                    
                case AMOTION_EVENT_ACTION_UP:
                case AMOTION_EVENT_ACTION_POINTER_UP:
                    io.MouseDown[0] = false;
                    io.MousePos = ImVec2(x, y);
                    return 1;
                    
                case AMOTION_EVENT_ACTION_MOVE:
                    io.MousePos = ImVec2(x, y);
                    return 1;
            }
            break;
        }
        
        case AINPUT_EVENT_TYPE_KEY: {
            int32_t keyCode = AKeyEvent_getKeyCode(event);
            int32_t action = AKeyEvent_getAction(event);
            
            if (keyCode == AKEYCODE_BACK) {
                return 1; // Consume back button
            }
            break;
        }
    }
    
    return 0;
}

// Hack thread
uintptr_t il2cppMap;
ProcMap anogsMap, il2cppMap2;

void* hack_thread(void*) {
    while (!il2cppMap) {
        il2cppMap2 = KittyMemory::getLibraryMap("libil2cpp.so");
        anogsMap = KittyMemory::getLibraryMap("libanogs.so");
        il2cppMap = Tools::GetBaseAddress("libil2cpp.so");
        sleep(5);
    }
    
    IL2Cpp::Il2CppAttach();
    
    // Hook functions
    Tools::Hook(
        (void*)(IL2Cpp::Il2CppGetMethodOffset(
            OBFUSCATE("Project.Plugins_d.dll"), 
            OBFUSCATE("NucleusDrive.Logic"), 
            OBFUSCATE("LVActorLinker"), 
            OBFUSCATE("SetVisible"), 
            3
        )), 
        (void*)SetVisible, 
        (void**)&_SetVisible
    );
    
    set_depth = (void(*)(void*, float))IL2Cpp::Il2CppGetMethodOffset(
        OBFUSCATE("Project_d.dll"), 
        OBFUSCATE(""), 
        OBFUSCATE("Moba_Camera"), 
        OBFUSCATE("set_currentZoomRate"), 
        1
    );
    
    Tools::Hook(
        (void*)(uintptr_t)IL2Cpp::Il2CppGetMethodOffset(
            OBFUSCATE("Project_d.dll"), 
            OBFUSCATE(""), 
            OBFUSCATE("Moba_Camera"), 
            OBFUSCATE("Update"), 
            0
        ), 
        (void*)CameraSystemUpdate, 
        (void**)&old_CameraSystemUpdate
    );
    
    return nullptr;
}

// Process application commands
static void engine_handle_cmd(struct android_app* app, int32_t cmd) {
    Engine* engine = (Engine*)app->userData;
    
    switch (cmd) {
        case APP_CMD_SAVE_STATE:
            break;
            
        case APP_CMD_INIT_WINDOW:
            if (engine->app->window != NULL) {
                engine_init_display(engine);
                engine_draw_frame(engine);
                engine->animating = true;
            }
            break;
            
        case APP_CMD_TERM_WINDOW:
            engine_term_display(engine);
            break;
            
        case APP_CMD_GAINED_FOCUS:
            engine->animating = true;
            break;
            
        case APP_CMD_LOST_FOCUS:
            engine->animating = false;
            engine_draw_frame(engine);
            break;
            
        case APP_CMD_WINDOW_RESIZED:
        case APP_CMD_CONFIG_CHANGED:
            if (engine->display != EGL_NO_DISPLAY && engine->surface != EGL_NO_SURFACE) {
                eglQuerySurface(engine->display, engine->surface, EGL_WIDTH, &engine->width);
                eglQuerySurface(engine->display, engine->surface, EGL_HEIGHT, &engine->height);
            }
            break;
    }
}

// Main entry point - Pure Native
void android_main(struct android_app* state) {
    memset(&g_engine, 0, sizeof(Engine));
    
    state->userData = &g_engine;
    state->onAppCmd = engine_handle_cmd;
    state->onInputEvent = engine_handle_input;
    g_engine.app = state;
    
    // Start hack thread
    pthread_t gameThread;
    pthread_create(&gameThread, NULL, hack_thread, NULL);
    
    // Main loop
    while (true) {
        int events;
        struct android_poll_source* source;
        
        // Poll all pending events
        while (ALooper_pollAll(g_engine.animating ? 0 : -1, NULL, &events, (void**)&source) >= 0) {
            if (source != NULL) {
                source->process(state, source);
            }
            
            if (state->destroyRequested != 0) {
                engine_term_display(&g_engine);
                return;
            }
        }
        
        // Draw frame if animating
        if (g_engine.animating) {
            engine_draw_frame(&g_engine);
        }
    }
}