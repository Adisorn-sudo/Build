#include <android/native_activity.h>
#include <android/native_window.h>
#include <android/looper.h>
#include <android/input.h>
#include <android/configuration.h>
#include <android_native_app_glue.h>
#include <errno.h>

#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <sstream>
#include <vector>

#include <pthread.h>
#include <codecvt>
#include <chrono>
#include <queue>

#include "ImGui/imgui_internal.h"
#include "ImGui/imgui.h"
#include "ImGui/backends/imgui_impl_android.h"
#include "ImGui/backends/imgui_impl_opengl3.h"

#include <EGL/egl.h>
#include <GLES3/gl3.h>

#include <android/asset_manager.h>
#include <sys/system_properties.h>

#include <string>

//====================================
#include "ImGui/FONTS/DEFAULT.h"
//=====================================
#include <Includes/Utils.h>
#include <Includes/Dobby/dobby.h>
#include <Includes/obfuscate.h>
#include "KittyMemory/MemoryPatch.h"
#include "TuanMeta/Call_Me.h"
#include "Hook.h"

//Ida Pro Define
typedef uint32_t _DWORD;
typedef uint64_t _QWORD;
#define __int8 char
#define __int16 short
#define __int32 int
#define __int64 long long

// Global State
struct EngineState {
    struct android_app* app;
    
    EGLDisplay display;
    EGLSurface surface;
    EGLContext context;
    
    int32_t width;
    int32_t height;
    
    bool initialized;
    bool running;
    
    ImGuiWindow* window;
};

static EngineState g_Engine = {0};
ImGuiWindow* g_window = NULL;  // Global window variable for menu.h

struct My_Patches {
    MemoryPatch patch;
} hexPatches;

// EGL Initialization
static int engine_init_display(EngineState* engine) {
    const EGLint attribs[] = {
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_BLUE_SIZE, 8,
        EGL_GREEN_SIZE, 8,
        EGL_RED_SIZE, 8,
        EGL_ALPHA_SIZE, 8,
        EGL_DEPTH_SIZE, 24,
        EGL_STENCIL_SIZE, 8,
        EGL_NONE
    };
    
    EGLint w, h, format;
    EGLint numConfigs;
    EGLConfig config;
    
    EGLDisplay display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    eglInitialize(display, 0, 0);
    
    eglChooseConfig(display, attribs, &config, 1, &numConfigs);
    eglGetConfigAttrib(display, config, EGL_NATIVE_VISUAL_ID, &format);
    
    ANativeWindow_setBuffersGeometry(engine->app->window, 0, 0, format);
    
    EGLSurface surface = eglCreateWindowSurface(display, config, engine->app->window, NULL);
    
    const EGLint context_attribs[] = {
        EGL_CONTEXT_CLIENT_VERSION, 3,
        EGL_NONE
    };
    
    EGLContext context = eglCreateContext(display, config, NULL, context_attribs);
    
    if (eglMakeCurrent(display, surface, surface, context) == EGL_FALSE) {
        LOGW("Unable to eglMakeCurrent");
        return -1;
    }
    
    eglQuerySurface(display, surface, EGL_WIDTH, &w);
    eglQuerySurface(display, surface, EGL_HEIGHT, &h);
    
    engine->display = display;
    engine->context = context;
    engine->surface = surface;
    engine->width = w;
    engine->height = h;
    
    return 0;
}

// ImGui Initialization
static void imgui_init(EngineState* engine) {
    if (engine->initialized) return;
    
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    
    // Set ImGui Style
    ImGui::StyleColorsClassic();
    
    // Setup Platform/Renderer backends
    ImGui_ImplAndroid_Init(engine->app->window);
    ImGui_ImplOpenGL3_Init("#version 300 es");
    ImGui::GetStyle().ScaleAllSizes(3.5f);
    
    static const ImWchar icons_ranges[] = { 0xf000, 0xf3ff, 0x0900, 0x097F, 0 };
    ImFontConfig font_config;
    ImFontConfig icons_config;
    ImFontConfig CustomFont;
    CustomFont.FontDataOwnedByAtlas = false;
    icons_config.MergeMode = true;
    icons_config.PixelSnapH = true;
    icons_config.OversampleH = 2.5;
    icons_config.OversampleV = 2.5;
    io.Fonts->AddFontFromMemoryTTF(const_cast<std::uint8_t*>(Custom3), sizeof(Custom3), 30.f, &CustomFont, io.Fonts->GetGlyphRangesCyrillic());
    
    // Set display size
    io.IniFilename = NULL;
    io.DisplaySize = ImVec2((float)engine->width, (float)engine->height);
    
    engine->initialized = true;
}

// Patches function
void Patches() {
    // Add your patches here
}

#include "menu.h"

// Render loop
static void engine_draw_frame(EngineState* engine) {
    if (!engine->initialized) return;
    if (engine->display == NULL) return;
    
    ImGuiIO& io = ImGui::GetIO();
    
    // Start the Dear ImGui frame
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame();
    ImGui::NewFrame();
    
    BeginDraw();
    g_window = ImGui::GetCurrentWindow();  // Update global window
    
    ImGui::EndFrame();
    ImGui::Render();
    
    glViewport(0, 0, (int)io.DisplaySize.x, (int)io.DisplaySize.y);
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    
    eglSwapBuffers(engine->display, engine->surface);
}

// Terminate display
static void engine_term_display(EngineState* engine) {
    if (engine->display != EGL_NO_DISPLAY) {
        eglMakeCurrent(engine->display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (engine->context != EGL_NO_CONTEXT) {
            eglDestroyContext(engine->display, engine->context);
        }
        if (engine->surface != EGL_NO_SURFACE) {
            eglDestroySurface(engine->display, engine->surface);
        }
        eglTerminate(engine->display);
    }
    
    engine->display = EGL_NO_DISPLAY;
    engine->context = EGL_NO_CONTEXT;
    engine->surface = EGL_NO_SURFACE;
}

// Shutdown ImGui
static void imgui_shutdown(EngineState* engine) {
    if (!engine->initialized) return;
    
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplAndroid_Shutdown();
    ImGui::DestroyContext();
    
    engine->initialized = false;
}

// Input handling
static int32_t engine_handle_input(struct android_app* app, AInputEvent* event) {
    EngineState* engine = (EngineState*)app->userData;
    
    if (!engine->initialized) return 0;
    
    if (AInputEvent_getType(event) == AINPUT_EVENT_TYPE_MOTION) {
        ImGuiIO& io = ImGui::GetIO();
        
        int32_t action = AMotionEvent_getAction(event);
        int32_t actionMasked = action & AMOTION_EVENT_ACTION_MASK;
        
        float x = AMotionEvent_getX(event, 0);
        float y = AMotionEvent_getY(event, 0);
        
        switch (actionMasked) {
            case AMOTION_EVENT_ACTION_DOWN:
            case AMOTION_EVENT_ACTION_POINTER_DOWN:
                io.MouseDown[0] = true;
                io.MousePos = ImVec2(x, y);
                break;
                
            case AMOTION_EVENT_ACTION_UP:
            case AMOTION_EVENT_ACTION_POINTER_UP:
                io.MouseDown[0] = false;
                break;
                
            case AMOTION_EVENT_ACTION_MOVE:
                io.MousePos = ImVec2(x, y);
                break;
        }
        
        return 1;
    }
    
    return 0;
}

// Command handling
static void engine_handle_cmd(struct android_app* app, int32_t cmd) {
    EngineState* engine = (EngineState*)app->userData;
    
    switch (cmd) {
        case APP_CMD_SAVE_STATE:
            break;
            
        case APP_CMD_INIT_WINDOW:
            if (engine->app->window != NULL) {
                engine_init_display(engine);
                imgui_init(engine);
                engine_draw_frame(engine);
            }
            break;
            
        case APP_CMD_TERM_WINDOW:
            imgui_shutdown(engine);
            engine_term_display(engine);
            break;
            
        case APP_CMD_GAINED_FOCUS:
            break;
            
        case APP_CMD_LOST_FOCUS:
            engine_draw_frame(engine);
            break;
            
        case APP_CMD_WINDOW_RESIZED:
        case APP_CMD_CONFIG_CHANGED:
            if (engine->display != EGL_NO_DISPLAY && engine->surface != EGL_NO_SURFACE) {
                eglQuerySurface(engine->display, engine->surface, EGL_WIDTH, &engine->width);
                eglQuerySurface(engine->display, engine->surface, EGL_HEIGHT, &engine->height);
                
                if (engine->initialized) {
                    ImGuiIO& io = ImGui::GetIO();
                    io.DisplaySize = ImVec2((float)engine->width, (float)engine->height);
                }
            }
            break;
    }
}

ProcMap handle, minelib;
ProcMap il2cppMap;  // Add il2cppMap declaration

void *hack_thread(void *arg) {
    while (!il2cppMap) {
        il2cppMap = KittyMemory::getLibraryMap("libil2cpp.so");
        minelib = KittyMemory::getLibraryMap("libminecraftpe.so");
        handle = KittyMemory::getLibraryMap("libminecraftpe.so");
        sleep(5);
    }
    
    IL2Cpp::Il2CppAttach();
    
    Tools::Hook((void *) (IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Project.Plugins_d.dll"), OBFUSCATE("NucleusDrive.Logic"), OBFUSCATE("LVActorLinker"), OBFUSCATE("SetVisible"), 3)), (void *) SetVisible, (void **) &_SetVisible);
    
    set_depth = (void(*)(void *,float))IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Project_d.dll"), OBFUSCATE(""), OBFUSCATE("Moba_Camera"), OBFUSCATE("set_currentZoomRate"), 1);
    Tools::Hook((void *) (uintptr_t)IL2Cpp::Il2CppGetMethodOffset(OBFUSCATE("Project_d.dll"), OBFUSCATE(""), OBFUSCATE("Moba_Camera"), OBFUSCATE("Update"), 0), (void *) CameraSystemUpdate, (void **) &old_CameraSystemUpdate);
    
    return nullptr;
}

// Main entry point
void android_main(struct android_app* state) {
    memset(&g_Engine, 0, sizeof(EngineState));
    
    state->userData = &g_Engine;
    state->onAppCmd = engine_handle_cmd;
    state->onInputEvent = engine_handle_input;
    g_Engine.app = state;
    
    // Start hack thread
    pthread_t gameThread;
    pthread_create(&gameThread, NULL, hack_thread, NULL);
    
    g_Engine.running = true;
    
    // Main loop
    while (g_Engine.running) {
        int ident;
        int events;
        struct android_poll_source* source;
        
        while ((ident = ALooper_pollAll(g_Engine.initialized ? 0 : -1, NULL, &events, (void**)&source)) >= 0) {
            if (source != NULL) {
                source->process(state, source);
            }
            
            if (state->destroyRequested != 0) {
                imgui_shutdown(&g_Engine);
                engine_term_display(&g_Engine);
                g_Engine.running = false;
                return;
            }
        }
        
        if (g_Engine.initialized) {
            engine_draw_frame(&g_Engine);
        }
    }
}