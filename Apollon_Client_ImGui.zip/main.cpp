#include <jni.h>
#include <android/native_activity.h>
#include <errno.h>

#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <sstream>
#include <vector>
#include <unordered_set>
#include <random>
#include <algorithm>
#include <ghc/filesystem.hpp>
namespace fs = ghc::filesystem;
#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"

#include <signal.h>
#include <pthread.h>
#include <codecvt>
#include <chrono>
#include <queue>

#include "ImGui/imgui_internal.h"
#include "ImGui/imgui.h"
#include "ImGui/backends/imgui_impl_android.h"
#include "ImGui/backends/imgui_impl_opengl3.h"

#include <EGL/egl.h>
#include <GLES3/gl3.h>
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include <android/asset_manager.h>
#include <android/asset_manager_jni.h>

#include <sys/system_properties.h>

#include <string>
#include <cmath>
#include <android/keycodes.h>

//====================================
#include "ImGui/FONTS/DEFAULT.h"
//=====================================
#include <Includes/Utils.h>
#include <Includes/Dobby/dobby.h>
#if defined(__aarch64__)
#include "Arm64/And64InlineHook.hpp"
#else
#include "Substrate/SubstrateHook.h"
#endif
#include "KittyMemory/MemoryPatch.h"
#include "KittyScanner/KittyScanner.hpp"
#include "ENCRYPT/obfuscate.h"
#include "ENCRYPT/oxorany.h"
#include "RGB.h"
#include "Chams.h"
#include "Includes/nlohmann/json.hpp"
#include "Includes/json.h"

typedef uint32_t _DWORD;
typedef uint64_t _QWORD;
#define __int8 char
#define __int16 short
#define __int32 int
#define __int64 long long
#define _BYTE unsigned char


using json = nlohmann::json;
int screenWidth = 0;
int screenHeight = 0;
float scaleGlobal, calcResX;
bool g_Initialized = false;
ImGuiWindow* g_window = NULL;
string GameName = oxorany("com.mojang.minecraftpe");
const char* MineLib = OBFUSCATE("libminecraftpe.so");


struct My_Patches {MemoryPatch
Font0, Font1, Font2, Font3, Font4, Font5, Font6, Font7, Font8, Font9, Font10,
NoHurtCam, NoCamDistortion, NoBoatRotation, NoCamSleep, PlaceCamera,
NoSlowDown,
LavaDrown, WaterDrown,
SlowDownTriggers,
Noclip,
AutoClickMine,
XrayCameraThird,
NoEmoteUseCooldown,
NoBlur1, NoBlur2,
FullBright,
AntiKnockBack,
NativeKeyHandler,
NoCaveVignette
;} hexPatches;


#include "offsets.h"
#include "dark_theme.h"
#include "Vector.h"
#include "hook_classes.h"
#include "variables.h"
#include "hook_utils.h"
#include "menu_utils.h"

// ========================================
// Global Variables for Rendering Loop
// ========================================
static pthread_t renderThread;
static pthread_t cheatThread;
static bool keepRunning = true;

// ========================================
// Render Loop Thread - รันแยกเพื่อวาด ImGui
// ========================================
void* render_loop(void* arg) {
    while (keepRunning) {
        if (g_Initialized) {
            // ImGui New Frame
            ImGui_ImplOpenGL3_NewFrame();
            ImGui_ImplAndroid_NewFrame();
            ImGui::NewFrame();

            // Draw your menu here
            DrawMenu(); // ฟังก์ชันนี้ควรอยู่ใน menu_utils.h

            // Render
            ImGui::Render();
            glViewport(0, 0, screenWidth, screenHeight);
            ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
        }
        
        usleep(16000); // ~60 FPS
    }
    return nullptr;
}

// ========================================
// Initialization Function - ย้ายจาก JNI init
// ========================================
void initialize_mod() {
    if (!g_Initialized) {
        IMGUI_CHECKVERSION();
        ImGui::CreateContext();
        ImGuiIO& io = ImGui::GetIO();
        
        // Set ImGui Style
        ImGui::StyleColorsClassic();
        embraceTheDarkness();
     
        // Setup Platform/Renderer backends
        ImGui_ImplOpenGL3_Init(oxorany("#version 100"));

        ImFontConfig CustomFont;
        CustomFont.FontDataOwnedByAtlas = false;

        static const ImWchar ranges[] = {
            0x0020, 0x00FF, // Basic Latin + Latin Supplement
            0x0100, 0x024F, // Extended Latin
            0x0370, 0x03FF, // Greek
            0x0400, 0x04FF, // Cyrillic
            0x0500, 0x052F, // Cyrillic Supplement
            0x2000, 0x206F, // General Punctuation
            0x2070, 0x209F, // Superscripts and Subscripts
            0x20A0, 0x20CF, // Currency Symbols
            0x2100, 0x214F, // Letterlike Symbols
            0x2150, 0x218F, // Number Forms
            0x2190, 0x21FF, // Arrows
            0x2200, 0x22FF, // Mathematical Operators
            0x2300, 0x23FF, // Miscellaneous Technical
            0x2400, 0x243F, // Control Pictures
            0x2440, 0x245F, // Optical Character Recognition
            0x2460, 0x24FF, // Enclosed Alphanumerics
            0x2500, 0x257F, // Box Drawing
            0x2580, 0x259F, // Block Elements
            0x25A0, 0x25FF, // Geometric Shapes
            0x2600, 0x26FF, // Miscellaneous Symbols
            0x2700, 0x27BF, // Dingbats
            0x3000, 0x303F, // CJK Symbols and Punctuation
            0x3040, 0x309F, // Hiragana
            0x30A0, 0x30FF, // Katakana
            0x4E00, 0x9FFF, // CJK Unified Ideographs
            0xFF00, 0xFFEF, // Halfwidth and Fullwidth Forms
            0,
        };

        io.Fonts->AddFontFromMemoryTTF(const_cast<std::uint8_t*>(Custom3), sizeof(Custom3), 30.f, &CustomFont, ranges);

        static bool loadedCfg = false;
        if (!loadedCfg) {
            std::ifstream file(oxorany("/data/data/") + GameName + oxorany("/xal/config.json"));
            if (file.good()) {
                // Load your config here
                // Example:
                // json j;
                // file >> j;
                // Load settings from j
            }
            loadedCfg = true;
        }

        g_Initialized = true;
        
        // Start render thread
        pthread_create(&renderThread, nullptr, render_loop, nullptr);
    }
}

// ========================================
// Hack Thread - ย้ายจาก JNI_OnLoad
// ========================================
void* hack_thread(void* arg) {
    // รอให้เกมโหลดเสร็จก่อน
    sleep(3);
    
    LOGI(OBFUSCATE("Mod is initializing..."));
    
    void* handle = dlopen(MineLib, RTLD_LAZY);
    if (!handle) {
        LOGE(OBFUSCATE("Failed to load %s"), MineLib);
        return nullptr;
    }
    
    // Initialize mod (ImGui, etc.)
    initialize_mod();
    
    // Setup all hooks
#if defined(__arm__)
    // ARM32 hooks
    MSHookThumb(reinterpret_cast<void*>((const void*(*)(...))dlsym(handle, OBFUSCATE("Java_com_mojang_minecraftpe_MainActivity_nativeKeyHandler"))), reinterpret_cast<void*>(new_Java_com_mojang_minecraftpe_MainActivity_nativeKeyHandler), reinterpret_cast<void**>(&old_Java_com_mojang_minecraftpe_MainActivity_nativeKeyHandler));
    hexPatches.NativeKeyHandler = MemoryPatch::createWithHex(MineLib, Offsets::NativeKeyHandler, "70 47");
    hexPatches.NativeKeyHandler.Modify();
    
    hexPatches.AntiKnockBack = MemoryPatch::createWithHex(MineLib, Offsets::LerpMotion, "70 47");
    
    hexPatches.FullBright = MemoryPatch::createWithHex(MineLib, Offsets::FullBright, "00 00 7A 44 70 47");
    hexPatches.SmoothLight = MemoryPatch::createWithHex(MineLib, Offsets::SmoothLight, "00 20 70 47");
    MSHookThumb((void *)getAbsoluteAddress(MineLib, Offsets::Block_getRenderLayer), (void *) Block_getRenderLayer, (void **) &old_Block_getRenderLayer);
    
    MSHookThumb((void *)getAbsoluteAddress(MineLib, Offsets::ClientInstanceOnTick), (void *) ClientInstance_onTick, (void **) &old_ClientInstance_onTick);
    
    MSHookThumb((void *)getAbsoluteAddress(MineLib, Offsets::Subtitle), (void *) TitleMessage_setSubtitle, (void **) &old_TitleMessage_setSubtitle);
    
    MSHookThumb((void *)getAbsoluteAddress(MineLib, Offsets::ShowPaperdoll), (void *) HudPlayerRenderer_update, (void **) &old_HudPlayerRenderer_update);
    
    MSHookThumb((void *)getAbsoluteAddress(MineLib, Offsets::SetupFog), (void *) LevelRendererPlayer_setupFog, (void **) &old_LevelRendererPlayer_setupFog);
    
    MSHookThumb((void *)getAbsoluteAddress(MineLib, Offsets::GetMaxPlayers), (void *) AppPlatform_getMaxPlayers, (void **) &old_AppPlatform_getMaxPlayers);
    
    MSHookThumb((void *)getAbsoluteAddress(MineLib, Offsets::UnlockMarket), (void *) Entitlement_UnlockMarket, (void **) &old_Entitlement_UnlockMarket);
    
    MSHookThumb((void *)getAbsoluteAddress(MineLib, Offsets::InMainMenu), (void *) InMainMenu, (void **) &old_InMainMenu);
    MSHookThumb((void *)getAbsoluteAddress(MineLib, Offsets::InGame), (void *) InGame, (void **) &old_InGame);
    MSHookThumb((void *)getAbsoluteAddress(MineLib, Offsets::InLanGame1), (void *) InLanGame1, (void **) &old_InLanGame1);
    MSHookThumb((void *)getAbsoluteAddress(MineLib, Offsets::InLanGame2), (void *) InLanGame2, (void **) &old_InLanGame2);
    
    MSHookThumb((void *)getAbsoluteAddress(MineLib, Offsets::Fov), (void *) PlayerFov, (void **) &old_PlayerFov);
    
    MSHookThumb((void *)getAbsoluteAddress(MineLib, Offsets::FogState), (void *) LevelRendererCamera_FogState, (void **) &old_LevelRendererCamera_FogState);
    
    hexPatches.Font0 = MemoryPatch::createWithHex(MineLib, Offsets::Font, "00 00 00 00");
    hexPatches.Font1 = MemoryPatch::createWithHex(MineLib, Offsets::Font, "CD CC CC 3D");
    hexPatches.Font2 = MemoryPatch::createWithHex(MineLib, Offsets::Font, "9A 99 99 3E");
    hexPatches.Font3 = MemoryPatch::createWithHex(MineLib, Offsets::Font, "66 66 E6 3E");
    hexPatches.Font4 = MemoryPatch::createWithHex(MineLib, Offsets::Font, "33 33 33 3F");
    hexPatches.Font5 = MemoryPatch::createWithHex(MineLib, Offsets::Font, "00 00 80 3F");
    hexPatches.Font6 = MemoryPatch::createWithHex(MineLib, Offsets::Font, "66 66 A6 3F");
    hexPatches.Font7 = MemoryPatch::createWithHex(MineLib, Offsets::Font, "CD CC CC 3F");
    hexPatches.Font8 = MemoryPatch::createWithHex(MineLib, Offsets::Font, "33 33 F3 3F");
    hexPatches.Font9 = MemoryPatch::createWithHex(MineLib, Offsets::Font, "9A 99 09 40");
    hexPatches.Font10 = MemoryPatch::createWithHex(MineLib, Offsets::Font, "00 00 20 40");
    
    MSHookThumb((void *)getAbsoluteAddress(MineLib, Offsets::FastDrop), (void *) DropItemTime, (void **) &old_DropItemTime);
    
    hexPatches.NoHurtCam = MemoryPatch::createWithHex(MineLib, Offsets::NoHurtCam, "70 47");
    
    hexPatches.NoCamDistortion = MemoryPatch::createWithHex(MineLib, Offsets::NoCamDistortion, "70 47");
    
    hexPatches.NoBoatRotation = MemoryPatch::createWithHex(MineLib, Offsets::NoBoatRotation, "70 47");
    
    hexPatches.NoCamSleep = MemoryPatch::createWithHex(MineLib, Offsets::NoCamSleep, "70 47");
    
    hexPatches.PlaceCamera = MemoryPatch::createWithHex(MineLib, Offsets::PlaceCamera, "70 47");
    
    MSHookThumb((void *)getAbsoluteAddress(MineLib, Offsets::SpeedHack), (void *) SpeedHack, (void **) &old_SpeedHack);
    
    MSHookThumb((void *)getAbsoluteAddress(MineLib, Offsets::NormalTick), (void *) NormalTick, (void **) &old_NormalTick);
    MSHookThumb((void *)getAbsoluteAddress(MineLib, Offsets::Intersects), (void*) Intersects, (void**) &old_Intersects);
    MSHookThumb((void *)getAbsoluteAddress(MineLib, Offsets::PlayerAuthInput), (void*) PlayerAuthInputPacket, (void**) &old_PlayerAuthInputPacket);
    
    MSHookThumb((void *)getAbsoluteAddress(MineLib, Offsets::WaterTrigger1), (void *) WasInWater, (void **) &old_WasInWater);
    MSHookThumb((void *)getAbsoluteAddress(MineLib, Offsets::WaterTrigger2), (void *) ActorHeadInWater, (void **) &old_ActorHeadInWater);
    MSHookThumb((void *)getAbsoluteAddress(MineLib, Offsets::WaterTrigger3), (void *) WaterSplashEffect, (void **) &old_WaterSplashEffect);
    
    hexPatches.SlowDownTriggers = MemoryPatch::createWithHex(MineLib, Offsets::SlowDownTriggers, "70 47");
    
    MSHookThumb((void *)getAbsoluteAddress(MineLib, Offsets::JumpHack), (void *) JumpHack, (void **) &old_JumpHack);
    
    MSHookThumb((void *)getAbsoluteAddress(MineLib, Offsets::WaterSpeed), (void *) WaterSpeed, (void **) &old_WaterSpeed);
    
    MSHookThumb((void *)getAbsoluteAddress(MineLib, Offsets::LavaSpeed), (void *) LavaSpeed, (void **) &old_LavaSpeed);
    
    hexPatches.NoSlowDown = MemoryPatch::createWithHex(MineLib, Offsets::NoSlowDown, "70 47");
    
    hexPatches.WaterDrown = MemoryPatch::createWithHex(MineLib, Offsets::WaterDrown, "70 47");
    
    hexPatches.LavaDrown = MemoryPatch::createWithHex(MineLib, Offsets::LavaDrown, "70 47");
    
    MSHookThumb((void *)getAbsoluteAddress(MineLib, Offsets::Gravity), (void *) Gravity, (void **) &old_Gravity);
    
    hexPatches.Noclip = MemoryPatch::createWithHex(MineLib, Offsets::Noclip, "70 47");
    
    hexPatches.AutoClickMine = MemoryPatch::createWithHex(MineLib, Offsets::AutoClickMine, "70 47");
    
    MSHookThumb((void *)getAbsoluteAddress(MineLib, Offsets::FastBridge), (void *) GameMode_FastBridge, (void **) &old_GameMode_FastBridge);
    
    MSHookThumb((void *)getAbsoluteAddress(MineLib, Offsets::BlockReach), (void *) GameMode_BlockReach, (void **) &old_GameMode_BlockReach);
    
    hexPatches.XrayCameraThird = MemoryPatch::createWithHex(MineLib, Offsets::XrayCameraThird, "70 47");
    
    hexPatches.NoEmoteUseCooldown = MemoryPatch::createWithHex(MineLib, Offsets::IsEmoting, "00 20 70 47");
    
    hexPatches.NoBlur1 = MemoryPatch::createWithHex(MineLib, Offsets::NoBlur1, "70 47");
    hexPatches.NoBlur2 = MemoryPatch::createWithHex(MineLib, Offsets::NoBlur2, "70 47");
    
#else // ARM64
    MSHookX86_64(reinterpret_cast<void*>((const void*(*)(...))dlsym(handle, OBFUSCATE("Java_com_mojang_minecraftpe_MainActivity_nativeKeyHandler"))), reinterpret_cast<void*>(new_Java_com_mojang_minecraftpe_MainActivity_nativeKeyHandler), reinterpret_cast<void**>(&old_Java_com_mojang_minecraftpe_MainActivity_nativeKeyHandler));
    hexPatches.NativeKeyHandler = MemoryPatch::createWithHex(MineLib, Offsets86_64::NativeKeyHandler, "C3");
    hexPatches.NativeKeyHandler.Modify();
    
    hexPatches.AntiKnockBack = MemoryPatch::createWithHex(MineLib, Offsets86_64::LerpMotion, "C3");
    
    hexPatches.FullBright = MemoryPatch::createWithHex(MineLib, Offsets86_64::FullBright, "B8 00 D0 77 44 66 0F 6E C0 C3");
    hexPatches.SmoothLight = MemoryPatch::createWithHex(MineLib, Offsets86_64::SmoothLight, "31 C0 C3");
    MSHookX86_64((void *)getAbsoluteAddress(MineLib, Offsets86_64::Block_getRenderLayer), (void *) Block_getRenderLayer, (void **) &old_Block_getRenderLayer);
    
    MSHookX86_64((void *)getAbsoluteAddress(MineLib, Offsets86_64::ClientInstanceOnTick), (void *) ClientInstance_onTick, (void **) &old_ClientInstance_onTick);

    MSHookX86_64((void *)getAbsoluteAddress(MineLib, Offsets86_64::Subtitle), (void *) TitleMessage_setSubtitle, (void **) &old_TitleMessage_setSubtitle);
    
    MSHookX86_64((void *)getAbsoluteAddress(MineLib, Offsets86_64::ShowPaperdoll), (void *) HudPlayerRenderer_update, (void **) &old_HudPlayerRenderer_update);
    
    MSHookX86_64((void *)getAbsoluteAddress(MineLib, Offsets86_64::SetupFog), (void *) LevelRendererPlayer_setupFog, (void **) &old_LevelRendererPlayer_setupFog);
    
    MSHookX86_64((void *)getAbsoluteAddress(MineLib, Offsets86_64::GetMaxPlayers), (void *) AppPlatform_getMaxPlayers, (void **) &old_AppPlatform_getMaxPlayers);
    
    MSHookX86_64((void *)getAbsoluteAddress(MineLib, Offsets86_64::UnlockMarket), (void *) Entitlement_UnlockMarket, (void **) &old_Entitlement_UnlockMarket);
    
    MSHookX86_64((void *)getAbsoluteAddress(MineLib, Offsets86_64::InMainMenu), (void *) InMainMenu, (void **) &old_InMainMenu);
    MSHookX86_64((void *)getAbsoluteAddress(MineLib, Offsets86_64::InGame), (void *) InGame, (void **) &old_InGame);
    MSHookX86_64((void *)getAbsoluteAddress(MineLib, Offsets86_64::InLanGame1), (void *) InLanGame1, (void **) &old_InLanGame1);
    MSHookX86_64((void *)getAbsoluteAddress(MineLib, Offsets86_64::InLanGame2), (void *) InLanGame2, (void **) &old_InLanGame2);
    
    MSHookX86_64((void *)getAbsoluteAddress(MineLib, Offsets86_64::Fov), (void *) PlayerFov, (void **) &old_PlayerFov);

    MSHookX86_64((void *)getAbsoluteAddress(MineLib, Offsets86_64::FogState), (void *) LevelRendererCamera_FogState, (void **) &old_LevelRendererCamera_FogState);

    hexPatches.Font0 = MemoryPatch::createWithHex(MineLib, Offsets86_64::Font, "00 00 00 3F");
    hexPatches.Font1 = MemoryPatch::createWithHex(MineLib, Offsets86_64::Font, "9A 99 19 3F");
    hexPatches.Font2 = MemoryPatch::createWithHex(MineLib, Offsets86_64::Font, "33 33 33 3F");
    hexPatches.Font3 = MemoryPatch::createWithHex(MineLib, Offsets86_64::Font, "CD CC 4C 3F");
    hexPatches.Font4 = MemoryPatch::createWithHex(MineLib, Offsets86_64::Font, "66 66 66 3F");
    hexPatches.Font5 = MemoryPatch::createWithHex(MineLib, Offsets86_64::Font, "00 00 80 3F");
    hexPatches.Font6 = MemoryPatch::createWithHex(MineLib, Offsets86_64::Font, "CD CC 8C 3F");
    hexPatches.Font7 = MemoryPatch::createWithHex(MineLib, Offsets86_64::Font, "9A 99 99 3F");
    hexPatches.Font8 = MemoryPatch::createWithHex(MineLib, Offsets86_64::Font, "66 66 A6 3F");
    hexPatches.Font9 = MemoryPatch::createWithHex(MineLib, Offsets86_64::Font, "33 33 B3 3F");
    hexPatches.Font10 = MemoryPatch::createWithHex(MineLib, Offsets86_64::Font, "00 00 C0 3F");
    
    MSHookX86_64((void *)getAbsoluteAddress(MineLib, Offsets86_64::FastDrop), (void *) DropItemTime, (void **) &old_DropItemTime);
    
    hexPatches.NoHurtCam = MemoryPatch::createWithHex(MineLib, Offsets86_64::NoHurtCam, "C3");
    
    hexPatches.NoCamDistortion = MemoryPatch::createWithHex(MineLib, Offsets86_64::NoCamDistortion, "C3");
    
    hexPatches.NoBoatRotation = MemoryPatch::createWithHex(MineLib, Offsets86_64::NoBoatRotation, "C3");
    
    hexPatches.NoCamSleep = MemoryPatch::createWithHex(MineLib, Offsets86_64::NoCamSleep, "C3");
    
    hexPatches.PlaceCamera = MemoryPatch::createWithHex(MineLib, Offsets86_64::PlaceCamera, "C3");
    
    MSHookX86_64((void *)getAbsoluteAddress(MineLib, Offsets86_64::SpeedHack), (void *) SpeedHack, (void **) &old_SpeedHack);
    
    MSHookX86_64((void *)getAbsoluteAddress(MineLib, Offsets86_64::NormalTick), (void*) NormalTick, (void**) &old_NormalTick);
    MSHookX86_64((void *)getAbsoluteAddress(MineLib, Offsets86_64::Intersects), (void*) Intersects, (void**) &old_Intersects);
    MSHookX86_64((void *)getAbsoluteAddress(MineLib, Offsets86_64::PlayerAuthInput), (void *) PlayerAuthInputPacket, (void **) &old_PlayerAuthInputPacket);
    
    MSHookX86_64((void *)getAbsoluteAddress(MineLib, Offsets86_64::WaterTrigger1), (void *) WasInWater, (void **) &old_WasInWater);
    MSHookX86_64((void *)getAbsoluteAddress(MineLib, Offsets86_64::WaterTrigger2), (void *) ActorHeadInWater, (void **) &old_ActorHeadInWater);
    MSHookX86_64((void *)getAbsoluteAddress(MineLib, Offsets86_64::WaterTrigger3), (void *) WaterSplashEffect, (void **) &old_WaterSplashEffect);
    
    hexPatches.SlowDownTriggers = MemoryPatch::createWithHex(MineLib, Offsets86_64::SlowDownTriggers, "C3");
    
    MSHookX86_64((void *)getAbsoluteAddress(MineLib, Offsets86_64::JumpHack), (void *) JumpHack, (void **) &old_JumpHack);
    
    MSHookX86_64((void *)getAbsoluteAddress(MineLib, Offsets86_64::ElytraSpeed), (void *) ElytraSpeed, (void **) &old_ElytraSpeed);
    
    MSHookX86_64((void *)getAbsoluteAddress(MineLib, Offsets86_64::WaterSpeed), (void *) WaterSpeed, (void **) &old_WaterSpeed);
    
    MSHookX86_64((void *)getAbsoluteAddress(MineLib, Offsets86_64::LavaSpeed), (void *) LavaSpeed, (void **) &old_LavaSpeed);
    
    hexPatches.NoSlowDown = MemoryPatch::createWithHex(MineLib, Offsets86_64::NoSlowDown, "C3");
    
    hexPatches.WaterDrown = MemoryPatch::createWithHex(MineLib, Offsets86_64::WaterDrown, "C3");
    
    hexPatches.LavaDrown = MemoryPatch::createWithHex(MineLib, Offsets86_64::LavaDrown, "C3");
    
    MSHookX86_64((void *)getAbsoluteAddress(MineLib, Offsets86_64::BoatSpeed), (void *) BoatSpeed, (void **) &old_BoatSpeed);
    
    MSHookX86_64((void *)getAbsoluteAddress(MineLib, Offsets86_64::Gravity), (void *) Gravity, (void **) &old_Gravity);
    
    hexPatches.Noclip = MemoryPatch::createWithHex(MineLib, Offsets86_64::Noclip, "C3");
    
    hexPatches.AutoClickMine = MemoryPatch::createWithHex(MineLib, Offsets86_64::AutoClickMine, "C3");
    
    MSHookX86_64((void *)getAbsoluteAddress(MineLib, Offsets86_64::FastBridge), (void *) GameMode_FastBridge, (void **) &old_GameMode_FastBridge);
    
    MSHookX86_64((void *)getAbsoluteAddress(MineLib, Offsets86_64::BlockReach), (void *) GameMode_BlockReach, (void **) &old_GameMode_BlockReach);
    
    hexPatches.XrayCameraThird = MemoryPatch::createWithHex(MineLib, Offsets86_64::XrayCameraThird, "C3");
    
    hexPatches.NoEmoteUseCooldown = MemoryPatch::createWithHex(MineLib, Offsets86_64::IsEmoting, "48 C7 C0 00 00 00 00 C3");
    
    hexPatches.NoBlur1 = MemoryPatch::createWithHex(MineLib, Offsets86_64::NoBlur1, "C3");
    hexPatches.NoBlur2 = MemoryPatch::createWithHex(MineLib, Offsets86_64::NoBlur2, "C3");
    
#endif
    
    LOGI(OBFUSCATE("Mod loaded successfully!"));
    
    return nullptr;
}

// ========================================
// CONSTRUCTOR - รันอัตโนมัติเมื่อ .so ถูกโหลด
// ========================================
__attribute__((constructor))
void lib_main() {
    LOGI(OBFUSCATE("Constructor called - Starting mod..."));
    
    // Start the hack thread
    pthread_create(&cheatThread, nullptr, hack_thread, nullptr);
}

// ========================================
// DESTRUCTOR - รันเมื่อ .so ถูก unload
// ========================================
__attribute__((destructor))
void lib_exit() {
    LOGI(OBFUSCATE("Destructor called - Cleaning up..."));
    
    keepRunning = false;
    
    // Wait for threads to finish
    if (renderThread) {
        pthread_join(renderThread, nullptr);
    }
    
    if (cheatThread) {
        pthread_join(cheatThread, nullptr);
    }
    
    // Cleanup ImGui
    if (g_Initialized) {
        ImGui_ImplOpenGL3_Shutdown();
        ImGui_ImplAndroid_Shutdown();
        ImGui::DestroyContext();
    }
    
    LOGI(OBFUSCATE("Cleanup complete"));
}
