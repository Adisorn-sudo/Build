#pragma once

#include <string>

// ===================================
// Global Variables Declaration
// ===================================

// Combat
bool AntiKnockBack = false;
bool FastDrop = false;
float BlockReach = 5.0f;

// Movement
bool SpeedHack = false;
float SpeedValue = 1.5f;

bool JumpHack = false;
float JumpValue = 1.5f;

bool Noclip = false;

bool Fly = false;
float FlySpeed = 2.0f;

bool WaterSpeed = false;
float WaterSpeedValue = 1.0f;

bool LavaSpeed = false;
float LavaSpeedValue = 1.0f;

bool ElytraSpeed = false;
float ElytraSpeedValue = 1.0f;

bool BoatSpeed = false;
float BoatSpeedValue = 1.0f;

// Visual
bool FullBright = false;
bool NoFog = false;
float Fov = 90.0f;
bool NoHurtCam = false;
bool Xray = false;
bool NoCamDistortion = false;
bool NoBoatRotation = false;
bool NoCamSleep = false;
bool NoCaveVignette = false;

// Player
bool WaterDrown = false;
bool LavaDrown = false;
bool NoSlowDown = false;
float Gravity = 1.0f;

// Misc
bool AutoClickMine = false;
bool FastBridge = false;
bool NoBlur = false;
int FontSize = 5;
bool NoEmoteUseCooldown = false;
bool PlaceCamera = false;

// Game State
bool isHackLoaded = false;
bool InMainMenuState = false;
bool InGameState = false;
bool InLanGameState = false;

// Player Info
std::string PlayerName = "";
float PlayerHealth = 20.0f;
float PlayerX = 0.0f;
float PlayerY = 0.0f;
float PlayerZ = 0.0f;

// UI State
bool ShowMenu = true;
bool ShowESP = false;
bool ShowCoordinates = true;

// Hook Function Pointers (forward declarations)
// These will be defined in your hook files

// Combat Hooks
void* (*old_GameMode_BlockReach)(void*, void*, void*, void*, void*) = nullptr;
void* (*old_GameMode_FastBridge)(void*, void*, void*) = nullptr;

// Movement Hooks
void* (*old_SpeedHack)(void*, float) = nullptr;
void* (*old_JumpHack)(void*, void*) = nullptr;
void* (*old_Gravity)(void*) = nullptr;
void* (*old_WaterSpeed)(void*, void*) = nullptr;
void* (*old_LavaSpeed)(void*, void*) = nullptr;
void* (*old_ElytraSpeed)(void*, void*) = nullptr;
void* (*old_BoatSpeed)(void*) = nullptr;

// Visual Hooks
void* (*old_Block_getRenderLayer)(void*, void*) = nullptr;
void* (*old_LevelRendererCamera_FogState)(void*, void*, void*) = nullptr;
void* (*old_PlayerFov)(void*) = nullptr;

// Player Hooks
void* (*old_WasInWater)(void*) = nullptr;
void* (*old_ActorHeadInWater)(void*) = nullptr;
void* (*old_WaterSplashEffect)(void*) = nullptr;

// Tick Hooks
void* (*old_ClientInstance_onTick)(void*) = nullptr;
void* (*old_NormalTick)(void*) = nullptr;

// Intersects
void* (*old_Intersects)(void*, void*, void*, void*) = nullptr;

// Player Auth Input
void* (*old_PlayerAuthInputPacket)(void*, void*) = nullptr;

// UI Hooks
void* (*old_TitleMessage_setSubtitle)(void*, void*) = nullptr;
void* (*old_HudPlayerRenderer_update)(void*, void*, void*, void*) = nullptr;
void* (*old_LevelRendererPlayer_setupFog)(void*, void*, void*, void*) = nullptr;

// Misc Hooks
void* (*old_AppPlatform_getMaxPlayers)(void*) = nullptr;
void* (*old_Entitlement_UnlockMarket)(void*) = nullptr;
void* (*old_DropItemTime)(void*) = nullptr;

// Game State Hooks
void* (*old_InMainMenu)(void*) = nullptr;
void* (*old_InGame)(void*) = nullptr;
void* (*old_InLanGame1)(void*) = nullptr;
void* (*old_InLanGame2)(void*) = nullptr;

// Native Key Handler (for input)
void* (*old_Java_com_mojang_minecraftpe_MainActivity_nativeKeyHandler)(void*, void*, int, int) = nullptr;

// ===================================
// Hook Function Declarations
// ===================================
// เหล่านี้จะต้อง implement ในไฟล์ hook_utils.h หรือไฟล์แยก

void* new_Java_com_mojang_minecraftpe_MainActivity_nativeKeyHandler(void* env, void* thiz, int keycode, int event);
void* SpeedHack(void* player, float deltaTime);
void* JumpHack(void* player, void* unknown);
void* Gravity(void* player);
void* WaterSpeed(void* player, void* unknown);
void* LavaSpeed(void* player, void* unknown);
void* ElytraSpeed(void* player, void* unknown);
void* BoatSpeed(void* boat);
void* GameMode_BlockReach(void* gamemode, void* p1, void* p2, void* p3, void* p4);
void* GameMode_FastBridge(void* gamemode, void* p1, void* p2);
void* Block_getRenderLayer(void* block, void* unknown);
void* ClientInstance_onTick(void* instance);
void* NormalTick(void* player);
void* Intersects(void* aabb1, void* aabb2, void* p3, void* p4);
void* PlayerAuthInputPacket(void* packet, void* player);
void* WasInWater(void* actor);
void* ActorHeadInWater(void* actor);
void* WaterSplashEffect(void* particle);
void* TitleMessage_setSubtitle(void* title, void* text);
void* HudPlayerRenderer_update(void* renderer, void* p1, void* p2, void* p3);
void* LevelRendererPlayer_setupFog(void* renderer, void* p1, void* p2, void* p3);
void* AppPlatform_getMaxPlayers(void* platform);
void* Entitlement_UnlockMarket(void* entitlement);
void* DropItemTime(void* player);
void* InMainMenu(void* screen);
void* InGame(void* screen);
void* InLanGame1(void* network);
void* InLanGame2(void* network);
void* PlayerFov(void* player);
void* LevelRendererCamera_FogState(void* renderer, void* camera, void* fogState);

// ===================================
// Logging Macros
// ===================================
#include <android/log.h>

#define LOG_TAG "MinecraftMod"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)

// ===================================
// Extern declarations (for main.cpp)
// ===================================
extern struct My_Patches hexPatches;
extern string GameName;
extern const char* MineLib;
extern bool g_Initialized;
extern int screenWidth;
extern int screenHeight;
